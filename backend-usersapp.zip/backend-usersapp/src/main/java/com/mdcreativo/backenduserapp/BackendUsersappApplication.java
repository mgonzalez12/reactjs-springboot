package com.mdcreativo.backenduserapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendUsersappApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendUsersappApplication.class, args);
	}

}
